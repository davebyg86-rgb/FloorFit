
package pl.floorfit.app

import android.content.ContentValues
import android.os.Bundle
import android.os.Build
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import android.graphics.pdf.PdfDocument
import java.io.OutputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            MaterialTheme(colorScheme = scheme) { App() }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Kalkulator", "Wizualizacja", "Eksport PDF", "O aplikacji")
    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("FloorFit") }) }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> CalculatorScreen()
                1 -> VisualizerScreen()
                2 -> ExportPdfScreen()
                3 -> AboutScreen()
            }
        }
    }
}

@Composable
fun CalculatorScreen() {
    var roomLen by remember { mutableStateOf("5.6") }
    var roomWid by remember { mutableStateOf("3.15") }
    var stripLen by remember { mutableStateOf("3.0") }
    var stripWid by remember { mutableStateOf("0.45") }
    var reservePct by remember { mutableStateOf("10") }

    val result = remember(roomLen, roomWid, stripLen, stripWid, reservePct) {
        calculateSets(
            roomLen.toDoubleOrNull() ?: 0.0,
            roomWid.toDoubleOrNull() ?: 0.0,
            stripLen.toDoubleOrNull() ?: 0.0,
            stripWid.toDoubleOrNull() ?: 0.0,
            (reservePct.toDoubleOrNull() ?: 0.0) / 100.0
        )
    }

    Column(
        Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Kalkulator naklejek", style = MaterialTheme.typography.headlineSmall)
        DimField("Długość pokoju (m)", roomLen) { roomLen = it }
        DimField("Szerokość pokoju (m)", roomWid) { roomWid = it }
        Divider()
        DimField("Długość zestawu (m)", stripLen) { stripLen = it }
        DimField("Szerokość zestawu (m)", stripWid) { stripWid = it }
        DimField("Zapas (%)", reservePct, KeyboardType.Number) { reservePct = it }
        ResultCard(result)
    }
}

@Composable
fun VisualizerScreen() {
    var roomLen by remember { mutableStateOf(5.6) }
    var roomWid by remember { mutableStateOf(3.15) }
    var stripLen by remember { mutableStateOf(3.0) }
    var stripWid by remember { mutableStateOf(0.45) }
    var swapped by remember { mutableStateOf(false) }

    val L = if (swapped) roomWid else roomLen
    val W = if (swapped) roomLen else roomWid

    val segPerRow = ceil(L / stripLen).toInt()
    val rows = ceil(W / stripWid).toInt()

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Wizualizacja ułożenia", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value="%.2f".format(roomLen), onValueChange={it.toDoubleOrNull()?.let{v->roomLen=v}}, label={Text("Pokój L (m)")})
            OutlinedTextField(value="%.2f".format(roomWid), onValueChange={it.toDoubleOrNull()?.let{v->roomWid=v}}, label={Text("Pokój W (m)")})
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value="%.2f".format(stripLen), onValueChange={it.toDoubleOrNull()?.let{v->stripLen=v}}, label={Text("Zestaw L (m)")})
            OutlinedTextField(value="%.2f".format(stripWid), onValueChange={it.toDoubleOrNull()?.let{v->stripWid=v}}, label={Text("Zestaw W (m)")})
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = swapped, onCheckedChange={swapped = it})
            Text("Obróć orientację (zamień L/W)")
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Rzędy: $rows, segmenty w rzędzie: $segPerRow")
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(240.dp)) {
                    Canvas(Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height
                        val rowHeight = height / rows
                        val segWidth = width / segPerRow
                        for (r in 0..rows) {
                            val y = rowHeight * r
                            drawLine(start = Offset(0f, y), end = Offset(width, y), strokeWidth = 2f)
                        }
                        for (c in 0..segPerRow) {
                            val x = segWidth * c
                            drawLine(start = Offset(x, 0f), end = Offset(x, height), strokeWidth = 1f)
                        }
                    }
                }
                Text("Siatka to przybliżony układ cięć; każda kratka to 1 segment.")
            }
        }
    }
}

@Composable
fun ExportPdfScreen() {
    val ctx = LocalContext.current
    var message by remember { mutableStateOf("Wygeneruj raport PDF z podsumowaniem obliczeń.") }
    var roomLen by remember { mutableStateOf("5.6") }
    var roomWid by remember { mutableStateOf("3.15") }
    var stripLen by remember { mutableStateOf("3.0") }
    var stripWid by remember { mutableStateOf("0.45") }
    var reservePct by remember { mutableStateOf("10") }

    val result = remember(roomLen, roomWid, stripLen, stripWid, reservePct) {
        calculateSets(
            roomLen.toDoubleOrNull() ?: 0.0,
            roomWid.toDoubleOrNull() ?: 0.0,
            stripLen.toDoubleOrNull() ?: 0.0,
            stripWid.toDoubleOrNull() ?: 0.0,
            (reservePct.toDoubleOrNull() ?: 0.0) / 100.0
        )
    }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Eksport PDF", style = MaterialTheme.typography.headlineSmall)
        DimField("Długość pokoju (m)", roomLen) { roomLen = it }
        DimField("Szerokość pokoju (m)", roomWid) { roomWid = it }
        DimField("Długość zestawu (m)", stripLen) { stripLen = it }
        DimField("Szerokość zestawu (m)", stripWid) { stripWid = it }
        DimField("Zapas (%)", reservePct, KeyboardType.Number) { reservePct = it }
        ResultCard(result)
        Button(onClick = {
            val ok = exportPdf(ctx,
                """FloorFit – Raport
Pokój: ${roomLen} × ${roomWid} m
Zestaw: ${stripLen} × ${stripWid} m
Zapas: ${reservePct}%
Minimalnie: ${result.minSets} zestawów
Z zapasem: ${result.withReserve} zestawów
Rzędy: ${result.rows}, Segmenty/rząd: ${result.segmentsPerRow}
Pokrycie: ${"%.1f".format(result.coverage*100)}%
""".trimIndent())
            message = if (ok) "Zapisano do Pobrane/FloorFit_raport.pdf" else "Błąd zapisu PDF."
        }) { Text("Zapisz PDF do Pobrane") }
        Text(message)
    }
}

fun exportPdf(context: android.content.Context, text: String): Boolean {
    return try {
        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 @72dpi
        val page = pdf.startPage(pageInfo)
        val canvas = page.canvas
        val paint = android.graphics.Paint().apply { textSize = 12f }
        val lines = text.split("\\n".toRegex())
        var y = 40f
        for (line in lines) {
            canvas.drawText(line, 40f, y, paint)
            y += 18f
        }
        pdf.finishPage(page)

        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "FloorFit_raport.pdf")
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
                pdf.writeTo(out)
            }
            if (Build.VERSION.SDK_INT >= 29) {
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            }
        }
        pdf.close()
        true
    } catch (e: Exception) {
        false
    }
}

@Composable
fun DimField(label: String, value: String, keyboardType: KeyboardType = KeyboardType.Decimal, onChange: (String)->Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun ResultCard(r: CalcResult) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Minimalnie: ${r.minSets} zestawów")
            Text("Z zapasem: ${r.withReserve} zestawów (zapas ${r.reservePct}%)")
            Text("Rzędy: ${r.rows} • Segmenty w rzędzie: ${r.segmentsPerRow}")
            Text("Pokrycie: ${"%.1f".format(r.coverage * 100)}%")
        }
    }
}

data class CalcResult(
    val minSets: Int,
    val withReserve: Int,
    val rows: Int,
    val segmentsPerRow: Int,
    val coverage: Double,
    val reservePct: Int
)

fun calculateSets(roomLen: Double, roomWid: Double, stripLen: Double, stripWid: Double, reserve: Double): CalcResult {
    if (roomLen <= 0 || roomWid <= 0 || stripLen <= 0 || stripWid <= 0) {
        return CalcResult(0, 0, 0, 0, 0.0, (reserve*100).toInt())
    }

    val optionA = neededSets(roomLen, roomWid, stripLen, stripWid)
    val optionB = neededSets(roomLen, roomWid, stripLen, stripWid, swap = true)

    val best = listOf(optionA, optionB).minBy { it.minSets }
    val withReserve = ceil(best.minSets * (1.0 + reserve)).toInt()
    return best.copy(withReserve = withReserve, reservePct = (reserve*100).toInt())
}

private fun neededSets(roomLen: Double, roomWid: Double, stripLen: Double, stripWid: Double, swap: Boolean = false): CalcResult {
    val (L, W) = if (swap) roomWid to roomLen else roomLen to roomWid

    val segmentsPerRow = ceil(L / stripLen).toInt()
    val rows = ceil(W / stripWid).toInt()
    val minSets = segmentsPerRow * rows

    val coveredL = segmentsPerRow * stripLen
    val coveredW = rows * stripWid
    val coverage = (L * W) / (coveredL * coveredW)

    return CalcResult(minSets, minSets, rows, segmentsPerRow, coverage.coerceIn(0.0, 1.0), 0)
}
